document.querySelector('#menu').a.addEventListener("click",goA);
	document.querySelector('#menu').b.addEventListener("click",goB);
	document.querySelector('#menu').c.addEventListener("click",goC);
	document.querySelector('#menu').d.addEventListener("click",goD);
	document.querySelector('#menu').e.addEventListener("click",goE);
	document.querySelector('#menu2').f.addEventListener("click",go1);
	document.querySelector('#menu2').g.addEventListener("click",go2);
	document.querySelector('#menu2').h.addEventListener("click",go3);
function goA(){
document.querySelector('section').innerHTML = "11% of people in the world are left-handed. Makes you wonder about all those left-handed desks there were in elementary school. When you mistakenly sat in one everything was wrong with the world.<img src='images/download.jpg'>";
}
function goB(){
document.querySelector('section').innerHTML = "The Mona Lisa has no eyebrows!<img src='images/download2.jpg'>";
}
function goC(){
document.querySelector('section').innerHTML = "Santa Klaus was created by Coca-Cola and he has been featured in Coke ads since the 1920s.<img src='images/download3.jpg'>";
}
function goD(){
document.querySelector('section').innerHTML = "Cats have over 100 vocal chords. Makes you wonder how many keys they can say Meow in! And cats can sleep 16 hours or more every 24 hours.<img src='images/download4.jpg'>";
}
function goE(){
document.querySelector('section').innerHTML = "Shrimp can only swim backwards, turtles breathe through their asses, fish can drown and a duck can't walk without bobbing its head.<img src='images/download5.jpg'>";
}
function go1(){
	document.querySelector('section').innerHTML = 6;
document.querySelector('section').style.backgroundColor = "#BF4E30";
}
function go2(){
document.querySelector('section').style.backgroundColor = "#E5EAFA";
}
function go3(){
document.querySelector('section').style.backgroundColor = "#77918F";
}